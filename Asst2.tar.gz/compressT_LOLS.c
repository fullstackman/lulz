//Andrew Marshall: alm266
//Brandon Diaz-Abreu: brd48

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/wait.h>


char fileName[510];
int partOne;	//use for instead of sizePart if offset passed is 0
int sizePart;
int parts;
int offset;

void *compress(void *off){
	
	int *tmp = (int *) off;
	int totalOffset = *tmp;
	
	//printf("FILE:%s, OFFSET:%d\n", fileName, totalOffset);
	
	FILE *fp;
	fp = fopen(fileName, "r");
	fseek(fp, totalOffset, SEEK_SET);
	
	int size;
	if(totalOffset == 0){
		size = partOne;
	}
	else{
		size = sizePart;
	}
	
	int orderNum = (totalOffset / sizePart);
	
	char input[size];
	//fgets wasn't inclusive of the final character so we add one
	fgets(input, size+1, fp);
	
	char output[size];
	output[0] = '\0';
	if(size > 2){
		char arrtmp[2];
		int num = 1;
		int i;
		
		for(i=1; i<size; ++i){
			if(input[i] != input[i-1]){
				switch(num){
					case 1:
						//print previous letter
						strncat(output, (char*) &input[i-1], 1);
						break;
					case 2:
						//print twice
						strncat(output, (char*) &input[i-1], 1);
						strncat(output, (char*) &input[i-1], 1);
						break;
					default:
						//print num times
						sprintf(arrtmp, "%d%c", num, input[i-1]);
						strcat(output, arrtmp);
				}
				num = 1;
			}
			else
				++num;
		}
		switch(num){
			case 1:
				//print previous letter
				strncat(output, (char*) &input[i-1], 1);
				break;
			case 2:
				//print twice
				strncat(output, (char*) &input[i-1], 1);
				strncat(output, (char*) &input[i-1], 1);
				break;
			default:
				//print num times
				sprintf(arrtmp, "%d%c", num, input[i-1]);
				strcat(output, arrtmp);
		}
	}
	else
		strcpy(output, input);

	
	//create output file of compressed string
	FILE* sampleOutput;
	char outputFile[510];
	fileName[strlen(fileName)- 4] = '_';
	
	if(orderNum == -1)
		snprintf(outputFile, 510, "%s_LOLS", fileName);
	else
		snprintf(outputFile, 510, "%s_LOLS%d", fileName, orderNum);
		
	sampleOutput = fopen(outputFile, "w+");
			
	printf("\tOUTPUT: %s, FILE: %s\n", output, outputFile);
	fputs(output,sampleOutput);	//write to file
	fclose(fp);
	
	free((void *)tmp);	//free malloc'd memory from parameter
	pthread_exit((void*) sampleOutput);
	return EXIT_SUCCESS;
}



int main(int argc, char *argv[])
{
	//various error checks
	if(argc > 3){	//too many arguments
		printf("\tERROR: Too many parameters\n");
		return 99;
	}
	
	if(argc < 3){	//not enough arguments
		printf("\tERROR: Not enough parameters\n");
		return -1;
	}
	int numParts = atoi(argv[2]);
	if(!numParts){	//if no number is entered
		printf("\tERROR: incorrect number entered!\n");
		return -2;
	}
	
	//need to check if we have permission to access file
	FILE * fp;
	fp = fopen(argv[1], "r");
	
	if(fp == NULL){
		printf("\tERROR: That file was not found!\n");
		return 404;
	}
	
	int fileNameLength = strlen(argv[1]);
	strncpy(fileName, argv[1], fileNameLength);
	fileName[fileNameLength+1] = '\0';
	
	//get size of text in file
	fseek(fp, 0, SEEK_END);
	//ftell was giving us one too many!
	size_t fsize = ftell(fp) - 1;
	
	fclose(fp);
	
	//is user asking for more parts than there are characters?
	if(numParts > fsize){
		printf("\tERROR: Too many parts requested\n");
		return -1;
	}
	
	//find size of parts
	sizePart = (int)fsize/numParts;
	offset = (int)fsize % numParts;
	partOne = sizePart + offset;
	parts = numParts;
	
	/* We can use this to delete the previous output files if the user calls this program on the same file multiple times!*/
	char* deleteCommand = malloc(43 + ( sizeof(char) * fileNameLength ) );
	sprintf(deleteCommand, "find -type f -name '%s_txt_LOLS*' -delete", fileName);
	system(deleteCommand);
	
	//here we should store the indeces to start and how much to do for each thread
	pthread_t pthreads[numParts];
	
	int i;
	for(i=0; i<numParts; i++){
		
		if(i == 0){		//if its the first part, increment by offset
			int *t = (int *)malloc(sizeof(int));	//malloc in order to ensure that threads do not try to use the same parameters
			int p = 0;
			*t = p;
			pthread_create( &(pthreads[i]), NULL, &compress, (void *)t );
		}
		else{
			int *t = (int *)malloc(sizeof(int));
			int p = ((i * sizePart) + offset);
			*t = p;
			pthread_create( &(pthreads[i]), NULL, &compress, (void *)t );
		}
		
		if(pthreads[i] == 0){
			printf("ERROR CREATING THREADS\n");
			exit(1);
		}
	}
	
	// wait for threads to finish working
	for (i=0; i<numParts; i++) {
		pthread_join(pthreads[i], NULL);
	}
	
	return EXIT_SUCCESS;
}

